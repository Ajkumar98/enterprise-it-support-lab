# Microsoft Intune Device Management

## Objective

Demonstrate an understanding of modern endpoint-management workflows.

## Example Workflow

1. Prepare Windows 11 device.
2. Enrol the device into Intune.
3. Confirm device ownership and compliance state.
4. Apply configuration profiles.
5. Deploy required applications.
6. Verify policy synchronisation.
7. Test end-user access.
8. Record deployment outcome.

## Example Policies

- Password requirements
- Windows Update configuration
- Device compliance
- Microsoft Defender configuration
- Application deployment

## Troubleshooting Intune

- Confirm device has internet access.
- Verify user/device enrolment.
- Check device compliance status.
- Trigger a manual sync.
- Review configuration profile status.
- Review application deployment status.
- Restart the device where appropriate.
- Capture error codes before escalation.

## SCCM Connection

In an enterprise environment, SCCM may be used for traditional endpoint imaging, software deployment and patching, while Intune supports cloud-based modern management.
