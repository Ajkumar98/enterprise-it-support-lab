# Sample Service Desk Tickets

## Ticket 001 — User Account Locked

**Priority:** Medium  
**Category:** Access / Active Directory  
**Issue:** User unable to sign in after several failed password attempts.

**Actions Taken**
- Verified user identity.
- Checked Active Directory account status.
- Confirmed account lockout.
- Unlocked account.
- Asked user to update stored credentials.
- Confirmed successful login.

**Resolution:** Account restored and user able to work normally.

---

## Ticket 002 — Laptop Cannot Resolve Internal Server

**Priority:** Medium  
**Category:** Network / DNS  
**Issue:** User could access internet websites but not an internal server by hostname.

**Actions Taken**
- Checked `ipconfig /all`.
- Verified network connectivity.
- Tested server connectivity by IP.
- Used `nslookup` to identify DNS resolution issue.
- Corrected workstation DNS configuration.
- Flushed DNS cache.

**Resolution:** Internal hostname resolved successfully.

---

## Ticket 003 — Microsoft 365 Sign-In Failure

**Priority:** High  
**Category:** Microsoft 365  
**Issue:** User could not access Outlook or Teams.

**Actions Taken**
- Confirmed internet access.
- Verified account state.
- Confirmed Microsoft 365 licence.
- Tested browser sign-in.
- Reviewed cached sign-in session.
- Re-authenticated applications.

**Resolution:** Outlook and Teams access restored.

---

## Ticket 004 — Windows 11 Software Deployment

**Priority:** Low  
**Category:** Endpoint Management  
**Issue:** Approved application not available on newly deployed laptop.

**Actions Taken**
- Confirmed device enrolment.
- Checked Intune/SCCM deployment assignment.
- Triggered policy sync.
- Restarted device.
- Verified installation.

**Resolution:** Application successfully deployed.

---

## Ticket 005 — Shared Printer Offline

**Priority:** Medium  
**Category:** Printing  
**Issue:** User unable to print to network printer.

**Actions Taken**
- Confirmed scope of outage.
- Verified printer network connectivity.
- Checked print queue.
- Restarted Print Spooler.
- Re-added printer connection.
- Printed test page.

**Resolution:** Printing service restored.
