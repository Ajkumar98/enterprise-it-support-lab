# Group Policy Lab

## Objective

Demonstrate understanding of Group Policy used to standardise Windows endpoint settings.

## Example Policies

### Desktop Security Policy
- Enable screen lock after inactivity
- Prevent users changing selected system settings
- Apply corporate desktop configuration

### Windows Update Policy
- Configure automatic updates
- Define restart behaviour
- Reduce unmanaged endpoint risk

### Mapped Drive Policy
- Map a shared drive based on group membership

## Validation

Useful commands:

```powershell
gpupdate /force
gpresult /r
```

## Troubleshooting Process

1. Confirm the computer/user is in the expected OU.
2. Check whether the GPO is linked to the OU.
3. Verify security filtering.
4. Run `gpupdate /force`.
5. Review `gpresult /r`.
6. Check Event Viewer for Group Policy errors.
7. Document findings and resolution.
