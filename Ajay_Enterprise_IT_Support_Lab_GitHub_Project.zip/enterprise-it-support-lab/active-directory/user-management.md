# Active Directory User Management

## Objective

Demonstrate common Level 1 / Level 2 Active Directory administration tasks.

## Example OU Structure

```text
contoso.local
├── Users
│   ├── Finance
│   ├── HR
│   ├── Operations
│   └── IT
├── Computers
│   ├── Workstations
│   └── Laptops
└── Groups
```

## User Creation Workflow

1. Confirm the approved new-starter request.
2. Verify the employee's full name, department, manager and start date.
3. Create the user in the correct OU.
4. Assign a temporary password.
5. Require password change at first logon.
6. Add the user to approved security groups.
7. Confirm required shared-folder and application access.
8. Update the Service Desk ticket.
9. Provide credentials securely according to company policy.

## Common Support Tasks

- Reset password
- Unlock account
- Disable departed-user accounts
- Add or remove security-group membership
- Check account expiry
- Review locked/disabled status
- Verify OU placement
- Confirm computer objects

## Example Interview Explanation

I use a structured approach when managing Active Directory accounts. I first confirm the approved request, make the required account or group change, validate the result and record the activity in the ticket.
