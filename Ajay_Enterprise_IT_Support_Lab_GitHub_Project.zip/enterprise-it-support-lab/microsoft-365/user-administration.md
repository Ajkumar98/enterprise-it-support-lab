# Microsoft 365 User Administration

## Objective

Document common end-user administration workflows for Microsoft 365.

## Example Tasks

- Create or verify user accounts
- Assign licences
- Reset passwords
- Review sign-in issues
- Support Outlook and Teams access
- Manage Exchange-related user settings
- Support SharePoint access
- Verify group membership
- Assist with MFA registration issues

## New Starter Checklist

- Confirm identity account exists
- Confirm Microsoft 365 licence
- Verify mailbox
- Confirm Teams access
- Confirm SharePoint access
- Verify required group memberships
- Test sign-in
- Record completion in ticket

## Troubleshooting Example: User Cannot Access Outlook

1. Confirm scope and error message.
2. Check internet connectivity.
3. Confirm account credentials.
4. Verify Microsoft 365 service availability.
5. Check account/licence status.
6. Test Outlook Web Access.
7. Re-create Outlook profile if appropriate.
8. Escalate with evidence if unresolved.
