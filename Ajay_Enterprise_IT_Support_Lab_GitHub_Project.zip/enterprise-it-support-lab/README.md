# Microsoft 365 & Azure Hybrid IT Support Lab

## Overview

This project simulates a small corporate IT environment designed to demonstrate practical Level 1 / Level 2 IT Support skills.

The lab focuses on common tasks performed by Service Desk, Desktop Support and IT Support professionals, including user administration, Windows support, Microsoft 365, Active Directory, Intune, PowerShell, networking and troubleshooting.

> **Important:** This repository is a portfolio lab. All users, company names, devices, IP addresses and tickets are fictional.

## Business Scenario

**Company:** Contoso Services Australia  
**Users:** 20 fictional employees  
**Environment:** Hybrid Microsoft environment  
**Primary Location:** Melbourne, Australia

The IT team supports end users across Windows 10/11 devices and manages identity, Microsoft 365 services, endpoint configuration and common network issues.

## Technologies Demonstrated

- Windows 10 / Windows 11
- Windows Server 2019
- Active Directory Domain Services
- Microsoft Entra ID / Azure AD concepts
- Microsoft 365
- Microsoft Intune
- SCCM concepts
- PowerShell
- DNS / DHCP / TCP-IP
- VPN troubleshooting
- Group Policy
- Hyper-V
- Service Desk ticket documentation
- Remote and onsite support workflows

## Lab Architecture

See: `architecture/network-diagram.svg`

### Example Environment

- Domain Controller: `DC01`
- Domain: `contoso.local`
- File Server: `FS01`
- Windows Client: `WIN11-01`
- IT Admin Workstation: `IT-ADMIN01`
- Example subnet: `192.168.10.0/24`

## Project Objectives

1. Build a small Windows Server domain environment.
2. Create users, groups and organisational units in Active Directory.
3. Apply Group Policy to Windows endpoints.
4. Demonstrate Microsoft 365 and Entra ID administration concepts.
5. Document Intune device-management workflows.
6. Automate repetitive support tasks using PowerShell.
7. Troubleshoot realistic IT support incidents.
8. Document ticket resolution using a professional Service Desk format.

## Repository Structure

```text
enterprise-it-support-lab/
├── README.md
├── architecture/
│   └── network-diagram.svg
├── active-directory/
│   ├── user-management.md
│   └── group-policy.md
├── microsoft-365/
│   └── user-administration.md
├── intune/
│   └── device-management.md
├── powershell/
│   ├── create-users.ps1
│   ├── system-info.ps1
│   ├── connectivity-check.ps1
│   └── unlock-user.ps1
├── tickets/
│   └── sample-service-desk-tickets.md
├── troubleshooting/
│   ├── account-lockout.md
│   ├── dns-issue.md
│   ├── printer-issue.md
│   └── microsoft-365-issue.md
└── screenshots/
```

## Key Skills Demonstrated

### Level 1 / Level 2 Support

- Incident triage
- User account support
- Password reset and account unlock
- Hardware and software troubleshooting
- Windows endpoint support
- Network troubleshooting
- Printer troubleshooting
- Microsoft 365 support
- Remote support methodology
- SLA-aware ticket documentation

### Active Directory

- User creation
- Security groups
- Organisational Units
- Password reset
- Account unlock
- Group membership
- Basic Group Policy

### PowerShell

The scripts in the `powershell` directory demonstrate simple administrative automation that can be discussed during interviews.

They are written for a lab environment and should be reviewed before use in production.

## Example Interview Talking Point

> I built a hybrid IT support lab to practise real Level 1 and Level 2 support scenarios. I configured a Windows Server domain, created users and security groups, documented Group Policy, worked through Microsoft 365 and Intune administration scenarios, and wrote PowerShell scripts for common support tasks such as connectivity testing and collecting system information. I also documented realistic Service Desk incidents using troubleshooting and resolution notes.

## Suggested Screenshots to Add

After completing the lab, add your own screenshots showing:

- Active Directory Users and Computers
- Your OU structure
- Example user properties
- Group Policy Management
- Windows 11 domain membership
- Intune device list
- Microsoft 365 Admin Centre
- PowerShell script output
- `ipconfig /all`
- `nslookup`
- Hyper-V virtual machines

Do not upload passwords, tenant IDs, licence keys, private IP details from real workplaces, customer information or any confidential business data.

## Future Improvements

- Add Microsoft Entra ID test tenant screenshots
- Add Intune compliance policies
- Add Microsoft Defender endpoint scenarios
- Add basic PowerShell reporting
- Add ticket metrics dashboard
- Add Azure Virtual Desktop or Citrix lab notes after gaining practical exposure

## Author

**Ajay Kumar Shah**  
IT Support Specialist | Level 1 / Level 2 Support  
Melbourne, Australia
