# Troubleshooting Scenario: DNS Issue

## Incident

A user can connect to the network but cannot access an internal resource by hostname.

## Commands

```cmd
ipconfig /all
ipconfig /flushdns
nslookup server.contoso.local
ping 192.168.10.10
```

## Troubleshooting

1. Confirm physical/Wi-Fi connectivity.
2. Check IP address and default gateway.
3. Verify configured DNS servers.
4. Test connectivity by IP address.
5. Test name resolution using `nslookup`.
6. Flush local DNS cache.
7. Renew IP settings if appropriate.
8. Escalate to network/server team if DNS infrastructure is unavailable.

## Example Root Cause

Incorrect DNS server manually configured on the workstation.
