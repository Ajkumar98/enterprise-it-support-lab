# Troubleshooting Scenario: Network Printer

## Incident

User reports that a shared office printer shows offline.

## Troubleshooting

1. Confirm whether one user or multiple users are affected.
2. Check printer power and network connection.
3. Ping the printer IP address.
4. Check Windows print queue.
5. Restart Print Spooler if appropriate.
6. Remove and re-add the printer.
7. Verify correct driver.
8. Print a test page.
9. Document the resolution.

## Useful PowerShell

```powershell
Get-Printer
Get-Service Spooler
Restart-Service Spooler
```
