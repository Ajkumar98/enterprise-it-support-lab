# Troubleshooting Scenario: Microsoft 365 Sign-In

## Incident

User reports they cannot sign in to Microsoft 365 applications.

## Troubleshooting

1. Confirm the exact error message.
2. Test internet connectivity.
3. Verify credentials.
4. Confirm account is enabled.
5. Confirm required licence is assigned.
6. Test browser-based Microsoft 365 sign-in.
7. Check MFA registration where relevant.
8. Clear cached credentials only when appropriate.
9. Re-test desktop applications.
10. Document or escalate with screenshots/error codes.

## Documentation

Record:
- user impact
- affected application
- error message
- troubleshooting performed
- result
- escalation details
