# Troubleshooting Scenario: Account Lockout

## Incident

User reports that they cannot sign in to their Windows computer.

## Troubleshooting

1. Confirm user identity.
2. Check Active Directory account status.
3. Identify whether the account is locked or disabled.
4. Unlock the account when authorised.
5. Reset password if required.
6. Ask the user to update stored credentials on mobile devices, Outlook or mapped resources.
7. Confirm successful sign-in.
8. Document the resolution.

## Example Ticket Resolution

**Root Cause:** Cached credentials on an old device repeatedly attempted authentication.

**Resolution:** Unlocked the account, updated the user's stored credentials and confirmed successful login.
