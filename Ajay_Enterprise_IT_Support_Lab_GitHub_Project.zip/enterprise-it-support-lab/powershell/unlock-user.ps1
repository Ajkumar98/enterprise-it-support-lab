<#
.SYNOPSIS
Checks and unlocks a fictional lab Active Directory user.

.NOTES
Use only in an authorised lab or administrative environment.
#>

Import-Module ActiveDirectory -ErrorAction Stop

$Username = Read-Host "Enter username"

try {
    $User = Get-ADUser -Identity $Username -Properties LockedOut, Enabled

    Write-Host "Enabled: $($User.Enabled)"
    Write-Host "Locked out: $($User.LockedOut)"

    if ($User.LockedOut) {
        Unlock-ADAccount -Identity $Username
        Write-Host "Account unlocked successfully."
    }
    else {
        Write-Host "Account is not locked."
    }
}
catch {
    Write-Error "Unable to process account: $($_.Exception.Message)"
}
