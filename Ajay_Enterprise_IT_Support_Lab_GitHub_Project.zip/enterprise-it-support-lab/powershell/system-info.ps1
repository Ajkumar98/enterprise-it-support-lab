<#
.SYNOPSIS
Collects basic Windows endpoint information for troubleshooting.
#>

$ComputerSystem = Get-CimInstance Win32_ComputerSystem
$OperatingSystem = Get-CimInstance Win32_OperatingSystem
$Bios = Get-CimInstance Win32_BIOS

$Info = [PSCustomObject]@{
    ComputerName = $env:COMPUTERNAME
    LoggedOnUser = $ComputerSystem.UserName
    Manufacturer = $ComputerSystem.Manufacturer
    Model = $ComputerSystem.Model
    OS = $OperatingSystem.Caption
    OSVersion = $OperatingSystem.Version
    SerialNumber = $Bios.SerialNumber
    LastBootTime = $OperatingSystem.LastBootUpTime
}

$Info | Format-List
