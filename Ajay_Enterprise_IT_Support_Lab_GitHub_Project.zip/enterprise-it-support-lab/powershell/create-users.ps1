<#
.SYNOPSIS
Creates fictional lab users in Active Directory from a CSV file.

.DESCRIPTION
Portfolio/lab example only. Requires the ActiveDirectory module and appropriate permissions.
Review before use.

Expected CSV columns:
FirstName,LastName,Username,Department,OU
#>

Import-Module ActiveDirectory -ErrorAction Stop

$CsvPath = ".\users.csv"

if (-not (Test-Path $CsvPath)) {
    Write-Error "CSV file not found: $CsvPath"
    exit 1
}

$Users = Import-Csv $CsvPath

foreach ($User in $Users) {
    try {
        $ExistingUser = Get-ADUser -Filter "SamAccountName -eq '$($User.Username)'" -ErrorAction SilentlyContinue

        if ($ExistingUser) {
            Write-Warning "User $($User.Username) already exists. Skipping."
            continue
        }

        $SecurePassword = Read-Host "Enter temporary password for $($User.Username)" -AsSecureString

        New-ADUser `
            -Name "$($User.FirstName) $($User.LastName)" `
            -GivenName $User.FirstName `
            -Surname $User.LastName `
            -SamAccountName $User.Username `
            -UserPrincipalName "$($User.Username)@contoso.local" `
            -Department $User.Department `
            -Path $User.OU `
            -AccountPassword $SecurePassword `
            -Enabled $true `
            -ChangePasswordAtLogon $true

        Write-Host "Created user: $($User.Username)"
    }
    catch {
        Write-Error "Failed to create $($User.Username): $($_.Exception.Message)"
    }
}
