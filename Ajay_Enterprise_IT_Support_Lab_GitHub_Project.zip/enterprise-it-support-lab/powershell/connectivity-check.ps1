<#
.SYNOPSIS
Runs simple workstation connectivity checks.
#>

$Targets = @(
    "8.8.8.8",
    "www.microsoft.com"
)

Write-Host "Computer: $env:COMPUTERNAME"
Write-Host "Testing default network configuration..."
ipconfig /all

foreach ($Target in $Targets) {
    Write-Host "`nTesting $Target"
    Test-NetConnection -ComputerName $Target -InformationLevel Detailed
}

Write-Host "`nDNS test:"
Resolve-DnsName www.microsoft.com -ErrorAction Continue
